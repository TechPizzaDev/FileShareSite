module.exports = function(hljs) {
    return {
        disableAutodetect: true
    };
};